package com.zybooks.inventoryproject;

public class InventoryModel {

    public boolean smsPermission;



}

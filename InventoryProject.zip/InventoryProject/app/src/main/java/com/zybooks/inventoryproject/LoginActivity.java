package com.zybooks.inventoryproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.os.Bundle;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    private final static String TAG = "LoginActivity";

    ArrayList<String> userCreds;


    SQLiteDatabase db;
    Button mLogin;
    Button mNewUser;
    EditText mUser;
    EditText mPassword;
    String mUserStr;
    String mPasswordStr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mLogin = (Button) findViewById(R.id.login_button);
        mLogin.setOnClickListener(this::login);

        mNewUser = (Button) findViewById(R.id.new_user_button);
        mNewUser.setOnClickListener(this::newUser);

        mUser = (EditText) findViewById(R.id.username_box);
        mUser.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                LoginActivity.this.mUserStr = mUser.getText().toString();
            }
        });

        mPassword = (EditText) findViewById(R.id.password_box);
        mPassword.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                LoginActivity.this.mPasswordStr = mPassword.getText().toString();
            }
        });

    }

    public void login(View view) {
        Intent intent = new Intent(this, GridActivity.class);
        startActivity(intent);
    }

    public void newUser(View view) {

    }
}

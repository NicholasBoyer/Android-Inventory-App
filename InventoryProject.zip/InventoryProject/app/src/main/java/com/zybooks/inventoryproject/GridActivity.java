package com.zybooks.inventoryproject;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;

public class GridActivity extends AppCompatActivity {

    Button mPermissions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        Button mPermissions = (Button) findViewById(R.id.nav_permissions);
        mPermissions.setOnClickListener(this::navPermissions);

    }

    public void navPermissions(View view) {
        Intent intent = new Intent(this, PermissionActivity.class);
        startActivity(intent);
    }
}

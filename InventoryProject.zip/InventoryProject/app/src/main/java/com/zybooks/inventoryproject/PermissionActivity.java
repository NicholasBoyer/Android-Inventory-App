package com.zybooks.inventoryproject;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
public class PermissionActivity extends AppCompatActivity {

    Button sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        sms = (Button) findViewById(R.id.sms_button);
        sms.setOnClickListener(this::setSms);

    }

    public void setSms(View viw) {

    }

}
